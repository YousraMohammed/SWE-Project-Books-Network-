import java.util.Vector;

public class Group {

  public String name;

  public Integer createdDate;

  public String info;

    /**
   * 
   * @element-type Posts
   */
  public Vector  contains;
    /**
   * 
   * @element-type User
   */
  public Vector  joins;
    /**
   * 
   * @element-type Book
   */
  public Vector  discuss;

}