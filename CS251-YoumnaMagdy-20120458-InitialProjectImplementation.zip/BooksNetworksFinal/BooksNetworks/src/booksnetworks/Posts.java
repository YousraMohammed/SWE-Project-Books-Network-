import booksnetworks.User;
import java.util.Vector;

public class Posts {

  public String post;

    public Group contains;
    /**
   * 
   * @element-type Comments
   */
  public Vector  includes;
    public User posts;

}