public class BooksUI {

/*  public createNewShelf : Button;

  public editShelf : Button;

  public addBookToShelf : Button;

  public search : Button;

  public addBook : Button;

  public addReview : Button;

  public likeReview : Button;

  public commentOnReview : Button;

  public removeBookFromShelf : Button;*/

}