
import booksnetworks.User;

public class CustomShelf extends Shelf {

  public String category;

    public User owns;

}