
import booksnetworks.User;


public class CurrentlyReading extends Shelf {

  public int expectedFinishDate;

    public User owns;

}