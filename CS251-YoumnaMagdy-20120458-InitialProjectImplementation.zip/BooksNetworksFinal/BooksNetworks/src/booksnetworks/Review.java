
import booksnetworks.Book;
import booksnetworks.User;

public class Review {

  public String review;

    public Book has;
    public User makes;

}