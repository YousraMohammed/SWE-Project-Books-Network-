package booksnetworks;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public  class UserUI extends JFrame implements ActionListener {
    JFrame f=new JFrame();
     JButton LogIn , SignUp , submit;
     JLabel UserName,Password;
     JTextField text1,text2;
     public UserUI(){
     setVisible(true);
     setSize(250,400);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     JPanel j=new JPanel();
     j.setSize(250,400);
     j.setLayout(null);
     setResizable(false);
     LogIn=new JButton("LogIn");
     LogIn.setBounds(40, 150, 80, 20);
     SignUp=new JButton("SignUp");
     SignUp.setBounds(40, 200, 80, 20);
     UserName=new JLabel("UserName");
     UserName.setBounds(5, 40, 70, 20);
     Password=new JLabel("Password");
     Password.setBounds(5, 90, 70,20);
    text1=new JTextField(" ");
    text1.setBounds(80,40,80,20);
     text2=new JTextField(" ");
     text2.setBounds(80,90,80,20);
     j.add(LogIn);
     j.add(SignUp);
     j.add(UserName);
     j.add(Password);
     j.add(text1);
     j.add(text2);
     add(j);
     LogIn.addActionListener(this);
     SignUp.addActionListener(this);
     //text1.addActionListener(this);
     //text2.addActionListener(this);
  
     }
  //  f.setTitle ("BooksNetwork");

 /* public signUp : Button;

  public logIn : Button;

  public logOut : Button;

  public edit : Button;

  public viewBooks : Button;

  public addRate : Button;

  public addFriend : Button;

  public like : Button;

  public comment : Button;

  public compete: Button;

  public accept : Button;

  public decline : Button;*/

    @Override
    public void actionPerformed(ActionEvent e) {
      
     if(e.getSource()==LogIn)
     { 
          
             String username ,password;
             username=text1.getText();
             password=text2.getText();
             UserManagement um=new UserManagement();
             
         try {
             if( um.logIn(username,password)==true)
             {
                 JFrame N = new JFrame();
                 N.setTitle("Sucess");
                 N.setVisible(true);
                 N.setSize(250,350);
                 N.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 N.setLayout(null);
                 N.setResizable(false);
                 JLabel Result;
                 UserName=new JLabel("Welcome "+username);
                 UserName.setBounds(20, 40, 40, 20);
                 N.add(UserName);
             }
             else{
                 JFrame N = new JFrame();
                 N.setTitle("Faild");
                 N.setVisible(true);
                 N.setSize(250,350);
                 N.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 N.setLayout(null);
                 N.setResizable(false);
                 JLabel Result;
                 UserName=new JLabel("Error"+ username);
                 UserName.setBounds(20, 40, 100, 20);
                 N.add(UserName);
             }
         
         } catch (SQLException ex) {
             Logger.getLogger(UserUI.class.getName()).log(Level.SEVERE, null, ex);
         } catch (ClassNotFoundException ex) {
             Logger.getLogger(UserUI.class.getName()).log(Level.SEVERE, null, ex);
         } 
             
             
         }
     
     else if(e.getSource()==SignUp)
     {
        
           System.out.print("here");
             String username ,password;
             username=text1.getText();
             password=text2.getText();
             UserManagement um=new UserManagement();
             try {
                 if( um.signUp(username,password).equals("Welcom"))
                 {
                     JFrame N = new JFrame();
                     N.setTitle("Welcome TO BooksNetwork ");
                     N.setVisible(true);
                     N.setSize(150,150);
                     N.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     N.setLayout(null);
                     N.setResizable(false);
                     JLabel Result;
                     UserName=new JLabel("Welcome to BooksNetwork "+username);
                     UserName.setBounds(20, 40, 100, 20);
                     N.add(UserName);
                 }
                 else{
                     JFrame N = new JFrame();
                     N.setTitle("Faild");
                     N.setVisible(true);
                     N.setSize(150,150);
                     N.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     N.setLayout(null);
                     N.setResizable(false);
                     JLabel Result;
                     UserName=new JLabel("InValid UserName or Password");
                     UserName.setBounds(20, 40, 100, 20);
                      N.add(UserName);
                 }
             } catch (ClassNotFoundException ex) {
                 Logger.getLogger(UserUI.class.getName()).log(Level.SEVERE, null, ex);
             } catch (SQLException ex) {
                 Logger.getLogger(UserUI.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
         
     }
        
         
         
     }
    



  
