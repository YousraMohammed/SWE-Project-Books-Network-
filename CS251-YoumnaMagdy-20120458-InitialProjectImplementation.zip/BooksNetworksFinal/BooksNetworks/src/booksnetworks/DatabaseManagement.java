package booksnetworks;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DatabaseManagement {
        int ID=3;
  public void connect()throws ClassNotFoundException, SQLException {
         Class.forName("com.mysql.jdbc.Driver");
          String url = "jdbc:mysql://localhost:3306/booksnetwork";
          Connection con = DriverManager.getConnection(url, "root", "");
          con.close();
  }
  public void addNewUser(User U) throws ClassNotFoundException, SQLException {
      Class.forName("com.mysql.jdbc.Driver");
          String url = "jdbc:mysql://localhost:3306/booksnetwork";
          Connection con = DriverManager.getConnection(url, "root", "");
          Statement stmt = con.createStatement();
          
          ID++;
          stmt.executeUpdate("INSERT INTO user (`ID`, `UserName`, `Password`, `HomeTown`)Values("+ID+",'"+U.username+"','"+U.password+"','"+U.hometown+"')");

          con.close();
  }

  public boolean validateCurrentUser(String username,String password) throws ClassNotFoundException, SQLException {
          Class.forName("com.mysql.jdbc.Driver");
          String url = "jdbc:mysql://localhost:3306/booksnetwork";
          Connection con = DriverManager.getConnection(url, "root", "");
         Statement stmt = con.createStatement();
         ResultSet results = stmt.executeQuery("Select * From user");

      while(results.next()) {
       int ID=results.getInt("ID");
       //System.out.print(results.getString("UserName"));
       //System.out.print(results.getString("Password"));
      if(results.getString("UserName").equals(username) && results.getString("Password").equals(password))
         {
            return true;
            
         }
      
        
       }
        return false;
  }
}
 /* public void searchBooks(Book b) {
  }

  public void addBooks(Book b) {
  }

  public void addShelf(Shelf s) {
  }

  public void addGroup(Group g) {
  }

  public void addPost(Posts p) {
  }

  public void addComment(Comments c) {
  }

  public void addBookToShelf(Book b) {
  }
*/
  

