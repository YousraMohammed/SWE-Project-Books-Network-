
import booksnetworks.User;

public class Comments {

  public String comment;

    public Posts includes;
    public User comments;

}