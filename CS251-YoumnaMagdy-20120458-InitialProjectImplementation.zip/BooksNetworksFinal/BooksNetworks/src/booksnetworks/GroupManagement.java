public class GroupManagement {

  public void createGroup() {
  }

  public void addUsersToGroup() {
  }

  public void acceptUsersToGroup() {
  }

  public void declineUsersToGroup() {
  }

  public void joinGroup() {
  }

  public void addPost() {
  }

  public void addComment() {
  }

  public void exitGroup() {
  }

}