package booksnetworks;
import booksnetworks.User;

public class ToRead extends Shelf {

  public Integer expectedStartDate;

    public User owns;

}