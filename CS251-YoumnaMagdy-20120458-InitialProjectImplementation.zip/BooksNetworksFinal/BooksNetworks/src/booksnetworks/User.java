package booksnetworks;
import booksnetworks.Book;
import java.util.Vector;

public class User {

  public String username;

  public String password;

  public String hometown;

 // public Book favouriteBooks [ ];

 // public String favouriteAuthors [ ];

 // public String favouriteCategories [ ];
     User() {
      username=" ";
      password=" ";
      hometown=" ";
   
     }
 /* public User(String N, String P,String H)
   {
      username=N;
      password=P;
      hometown=H;
  }

    /**
   * 
   * @element-type Review
   */
  public Vector  makes;
    public ToRead owns;
   // public CurrentlyReading owns;
    //public FinishedReading owns;
    /**
   * 
   * @element-type Custom Shelf
   */
//  public Vector  owns;
    /**
   * 
   * @element-type Book
   
  public Vector  keeps;
  public Vector  joins;
  public Posts[] posts;
  public Comments[]  comments;
  public Vector  myUserManagement;
  public User[] friends;
  //public Void LogIn()*/

 
       
   

}