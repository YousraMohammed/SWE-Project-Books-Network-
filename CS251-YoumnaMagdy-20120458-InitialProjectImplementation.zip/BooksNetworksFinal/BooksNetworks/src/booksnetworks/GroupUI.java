public class GroupUI {

 /* public createGroup : Button;

  public addUser : Button;

  public acceptUser : Button;

  public declineUser : Button;

  public join : Button;

  public post : Button;

  public comment : Button;

  public exit : Button;*/

}