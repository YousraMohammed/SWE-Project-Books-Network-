public class BooksManagement {

  public void createShelf() {
  }

  public void editShelf() {
  }

  public void addBooksToShelves() {
  }

  public Void searchByCategory() {
  return null;
  }

  public Void searchByName() {
  return null;
  }

  public Void searchByAuthor() {
  return null;
  }

  public void addNewBook() {
  }

  public void addReview() {
  }

  public void likeReview() {
  }

  public void commentOnReview() {
  }

  public void removeBookFromShelf() {
  }

  public void changeShelfName() {
  }

  public void changeShelfCategory() {
  }

}