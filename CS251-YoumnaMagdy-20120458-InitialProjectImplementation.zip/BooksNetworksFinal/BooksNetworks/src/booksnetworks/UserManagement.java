package booksnetworks;
import booksnetworks.DatabaseManagement;
import java.sql.SQLException;
import java.util.Vector;

public class UserManagement {

  //  public Vector  myUser;
    public DatabaseManagement DM=new DatabaseManagement();
  
   public String signUp(String UserName , String Password) throws ClassNotFoundException, SQLException {
       String U ,P;
       U=UserName;
       P=Password;
        String message;
        if(DM.validateCurrentUser(U,P)==true)
        { message="invalid UserName orPassword";
        System.out.println("invalid UserName orPassword");
        return message  ;
      
      }
      else{
         
         User NU=new User();
         NU.username=U;
         NU.password=P;
         NU.hometown="cairo";
         DM.addNewUser(NU);
         message ="Welcom";
         
                  
      return message;
      }
  }

  public boolean logIn(String username,String password) throws ClassNotFoundException, SQLException {
     String U ,P;
     U=username;
     P=password;
    //  DatabaseManagement DM=new DatabaseManagement();
      if(DM.validateCurrentUser(U,P)==true)
      { return true;
      
      }
      
       return false;
      
  }

  public void logOut() {
  }

  public void editBasicInfo() {
  }

  public void editFavouriteBooks() {
  }

  public void editFavouriteAuthors() {
  }

  public void editFavouriteCategories() {
  }

  /*public Book viewBooksInShelves() {
  return null;
  }

  public Book viewBooksByCategory() {
  return null;
  }*/

  public void addRate() {
  }

  public void addFriend() {
  }

  public void likeFriendActivity() {
  }

  public void commentOnFriendActivity() {
  }

  public void compete() {
  }

  public void acceptCompetetion() {
  }

  public void declineCompetetion() {
  }

}