
import booksnetworks.User;

public class FinishedReading extends Shelf {

  public int startDate;

  public int finishDate;

    public User owns;

}