package booksnetworks;

import java.util.Vector;


public class Book {

  public String Category;

  public String Name;

  public String Author;

    /**
   * 
   * @element-type Review
   */
  public Vector  has;
    /**
   * 
   * @element-type Shelf
   */
  public Vector  carries;
    /**
   * 
   * @element-type User
   */
  public Vector  keeps;
    /**
   * 
   * @element-type Group
   */
  public Vector  discuss;
    /**
   * 
   * @element-type User
   */
 // public Vector  keeps;

  public int calcAverageRate() 
  {
    return 0;
  }

}