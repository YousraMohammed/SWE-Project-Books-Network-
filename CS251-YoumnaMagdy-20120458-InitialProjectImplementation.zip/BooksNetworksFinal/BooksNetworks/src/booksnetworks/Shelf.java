import java.util.Vector;

public class Shelf {

  public String Name;

    /**
   * 
   * @element-type Book
   */
  public Vector  carries;

}