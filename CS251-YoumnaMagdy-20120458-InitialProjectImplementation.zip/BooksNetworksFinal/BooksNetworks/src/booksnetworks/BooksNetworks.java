/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booksnetworks;

import java.sql.*;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class BooksNetworks {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
         UserUI u=new UserUI();
       /* System.out.print("enter username ");
        Scanner in=new Scanner(System.in);
        String UserName=in.nextLine();
          System.out.print("enter password");
        String Password=in.nextLine();
        UserManagement U= new UserManagement();
       if( U.logIn(UserName, Password)==true)
               {
                  System.out.print("true");
                  
               }
        else
       {
           System.out.print("False");
       }*/
        
        

        
        
        // TODO code application logic here
       
    }
    
}
